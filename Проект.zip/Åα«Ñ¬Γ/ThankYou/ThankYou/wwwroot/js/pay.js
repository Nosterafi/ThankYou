﻿function setSum(event) {
    let input = document.getElementsByName("Tip.Sum")[0]
    let value = event.target.value

    input.value = value
}