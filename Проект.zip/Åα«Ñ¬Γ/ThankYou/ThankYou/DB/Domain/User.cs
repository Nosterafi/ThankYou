﻿namespace ThankYou.DB.Domain;

public partial class User
{
    public short Id { get; set; }

    public string Surname { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string? Patronymic { get; set; }

    public string PhoneNumber { get; set; } = null!;

    public string Password { get; set; } = null!;
}
